<?php

// 個別提案書の定義配列
$config['leafletArrs']=array(
							'A-Class'=>array(36=>'anshin2',48=>'anshin2',60=>'marugoto'),
							'B-Class'=>array(36=>'anshin2',48=>'anshin2',60=>'marugoto'),
							'CLA-Class'=>array(36=>'anshin2',48=>'anshin2',60=>'marugoto'),
							'C-Class Sedan'=>array(36=>'anshin2',48=>'anshin2',60=>'marugoto'),
							'C-Class Stationwagon'=>array(36=>'anshin2',48=>'anshin2',60=>'marugoto'),
							'C-Class Coupe'=>array(36=>'anshin2',48=>'anshin2',60=>'marugoto'),
							'E-Class Sedan'=>array(36=>'anshin2',48=>'anshin2',60=>'anshin'),
							'E-Class Stationwagon'=>array(36=>'anshin2',48=>'anshin2',60=>'anshin'),
							'E-Class Coupe'=>array(36=>'anshin2',48=>'anshin2',60=>'anshin'),
							'E-Class Cabriolet'=>array(36=>'anshin2',48=>'anshin2',60=>'anshin'),
							'S-Class'=>array(36=>'anshin2',48=>'anshin2',60=>'anshin'),
					);

?>