<?php
class users extends AppModel
{
var $name='users';
}
?>